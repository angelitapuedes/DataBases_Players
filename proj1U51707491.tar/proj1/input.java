
public class input{

public static void main(String args[]) 
    { 
 	System.out.println("Hi, please give me the flllowing prompts information to find your coach");
	
 	System.out.println("Hi, please give me the flllowing prompts information to find your coach");
    } 
}
