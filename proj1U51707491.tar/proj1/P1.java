import java.io.File;
import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.Collection;
//import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
//import java.util.Collections;
//import java.util.List;
import java.lang.String;
 

public class P1 {
    
	public static Scanner input;
	
	private final List<CoachSeason> coaches;
	private final List<Team> teams;
	private final List<CoachSeason> bestcoaches;
	private final List<CoachSeason> mathlist;
	//private final String str;
	//private final String str2;



	public P1() {
		/* initialize the data structures */
		// Data bases for CoachSeason and Team
		this.bestcoaches=new ArrayList<>();
		this.coaches = new ArrayList<>();
		this.teams = new ArrayList<>();
		this.mathlist=new ArrayList<>();
	}

	public void run() {
		final CommandParser parser = new CommandParser();

		System.out.println("The mini-DB of NBA coaches and teams");
		System.out.println("Please enter a command.  Enter 'help' for a list of commands.");
		System.out.println();
		System.out.print("> ");

		Command cmd;
		while ((cmd = parser.fetchCommand()) != null) {
			// System.out.println(cmd);

			boolean result = false;

			if (cmd.getCommand().equals("help")) {
				result = doHelp();

				/* You need to implement all the following commands */
			} else if (cmd.getCommand().equals("add_coach")) {
				System.out.print("Enter Coach/Season Details >>\n");
				System.out.print("CoachID: ");
				final String coachID = input.nextLine();
				System.out.print("Year: ");
				final int year = input.nextInt();
				input.nextLine();
				/*System.out.print("Year Order: ");
				int yearOrder = input.nextInt();*/
				input.nextLine();
				System.out.print("First Name: ");
				final String firstName = input.nextLine();
				System.out.print("Last Name: ");
				final String lastName = input.nextLine();
				System.out.print("Season Wins: ");
				final int seasonWin = input.nextInt();
				input.nextLine();
				System.out.print("Season Losses: ");
				final int seasonLoss = input.nextInt();
				input.nextLine();
				System.out.print("Playoff Wins: ");
				final int playOffWin = input.nextInt();
				input.nextLine();
				System.out.print("Playoff Losses: ");
				final int playOffLoss = input.nextInt();
				input.nextLine();
				System.out.print("Team: ");
				final String team = input.nextLine();
				
				//add new CoachSeason to coaches
				this.coaches.add(new CoachSeason(coachID, year, /*yearOrder,*/ firstName, lastName, seasonWin, seasonLoss, playOffWin, playOffLoss, team));

				System.out.println("Coaches Added: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));

			} else if (cmd.getCommand().equals("add_team")) {

				System.out.println("Enter team info >>");
				System.out.print("Team (abbr.): ");
				final String team = input.nextLine();
				System.out.print("Location: ");
				final String location = input.nextLine();
				System.out.print("Name: ");
				final String name = input.nextLine();
				System.out.print("League: ");
				final String league = input.nextLine();

				this.teams.add(new Team(team, location, name, league));

				System.out.println("Teams added: " + this.teams.toString().replaceAll("Team >>", "\nTeam >>"));

			} else if (cmd.getCommand().equals("print_coaches")) {
				// print_coaches();
				//System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));
				System.out.println(coaches);
			} else if (cmd.getCommand().equals("print_teams")) {
				System.out.println(teams);

			} else if (cmd.getCommand().equals("coaches_by_name")) {
				System.out.print("First Name of the Coach: ");
				final var coachfname = input.nextLine();
				System.out.print("Last Name of the Coach: ");
				final var coachlname = input.nextLine();
				for(final var coachsearchN : coaches) {
					if(coachsearchN.getFirstName().equals(coachfname)&&coachsearchN.getLastName().equals(coachlname)){
						//String lastnames=coachsearchN.getLastName();
						//System.out.println("Yes");
						//:wq
						//System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));
						System.out.println(coachsearchN.getCoachID()+" "+ coachsearchN.getYear()+ " "+ coachsearchN.getFirstName()+" "+ coachsearchN.getLastName()+" "+ coachsearchN.getSeasonWin()+
						" "+ coachsearchN.getSeasonLoss()+" "+ coachsearchN.getPlayoffWin()+" "+ coachsearchN.getPlayoffLoss()+" "+ coachsearchN.getTeam());
					}
					/*else{
						System.out.println("No");
					}*/
				}
			} else if (cmd.getCommand().equals("teams_by_city")) {
				System.out.print("Enter the City that you would like: ");
				final var teamcity = input.nextLine();
				for(final var teamsearchC : teams) {
					if(teamsearchC.getLocation().equals(teamcity)){
						//String lastnames=coachsearchN.getLastName();
						//System.out.println("Yes");
						//:wq
						//System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));
						System.out.println(teamsearchC.getTeam()+" "+ teamsearchC.getLocation()+ " "+ teamsearchC.getName()+" "+ teamsearchC.getLeague());
					}
					/*else{
						System.out.println("No");
					}*/
				}

			} else if (cmd.getCommand().startsWith("load_coaches")) {
				//check if FILENAME was provided, else prompt for it
				String fileName;
				if(cmd.getCommand().split(" ").length > 1) {
					fileName = cmd.getCommand().split(" ")[1];
				} else {
					System.out.print("Enter file name: ");
					fileName = input.nextLine();
				}

				//read input file into fileLines
				Scanner scanner = null;
				final List<String> fileLines = new ArrayList<>();
				try {
					scanner = new Scanner(new File(fileName));
					

					while (scanner.hasNextLine()) {
						fileLines.add(scanner.nextLine());
						
					}
				} catch (final Exception e) {
					System.out.println("Error occurred.");
					scanner.close();
					return;
				} finally {
					scanner.close();
				}
				System.out.print("");

				//parseInput and add to coaches list
				for(final String line : fileLines) {
					this.coaches.add(CoachSeason.parseInput(line));
				}
				System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));

				// Scanner cfreader = new Scanner(System.in);
				// String Cfile = cfreader.nextLine();
				// CoachSeason Load_Coaches= new CoachSeason();
				// if (Cfile == null) {
				// 	System.out.println(
				// 			"Invalid Command, I will take you back to the menu options, choose the coach load and type in a valid file!");
				// 	doHelp();
				// } else {
				// 	// Load_Coaches.load_coaches();
				// }

			} else if (cmd.getCommand().startsWith("load_teams")) {
				//check if FILENAME was provided, else prompt for it
				String fileName;
				if(cmd.getCommand().split(" ").length > 1) {
					fileName = cmd.getCommand().split(" ")[1];
				} else {
					System.out.print("Enter file name: ");
					fileName = input.nextLine();
				}

				//read input file into fileLines
				Scanner scanner = null;
				final List<String> fileLines = new ArrayList<>();
				try {
					scanner = new Scanner(new File(fileName));
					while (scanner.hasNextLine()) {
						fileLines.add(scanner.nextLine());
					}
				} catch (final Exception e) {
					System.out.println("Error occurred.");
					scanner.close();
					return;
				} finally {
					scanner.close();
				}

				//parseInput and add to teams list
				for(final String line : fileLines) {
					this.teams.add(Team.parseInput(line));
				}

				// Scanner tfreader = new Scanner(System.in);
				// String Tfile = tfreader.nextLine();
				// Team Load_Teames = new Team();
				// if (Tfile == null) {
				// 	System.out.println(
				// 			"Invalid Command, I will take you back to the menu options, choose the team_load and type in a valid file!");
				// 	doHelp();
				// } else {
				// 	Load_Teames.load_teams();
				// }
				System.out.println("Teams: " + this.teams.toString().replaceAll("Teams >>", "\n Teams >>"));

				
				

			} else if (cmd.getCommand().equals("best_coach")) {
				//Prompt give to ask for the specific year/season 
				System.out.print("Season: ");
				final var season = input.nextInt();
				input.nextLine();
				double NetWin=0;
				double lowest=0;
			//	final CoachSeason bestCoach = new CoachSeason(null, " ", null, null, "", "", "", "", null);
				//final CoachSeason var1;
				//1. Query through the list we have to find the season
				for(final var searchBestcoach : coaches) {
					if(searchBestcoach.getYear()==season){
						//Add those coaches to a seperate list for specified season
						this.bestcoaches.add(new CoachSeason(searchBestcoach.getCoachID(), searchBestcoach.getYear(), searchBestcoach.getFirstName(), searchBestcoach.getLastName(), searchBestcoach.getSeasonWin(), searchBestcoach.getSeasonLoss(), searchBestcoach.getPlayoffWin(), searchBestcoach.getPlayoffLoss(), searchBestcoach.getTeam()));
						}//Clear the list
				}//Run through best coaches list to perform math to solve the netwins for each coach
				for(final var searchnetWins : bestcoaches) {
					
						//Make 
						
						NetWin=(searchnetWins.getSeasonWin()-searchnetWins.getSeasonLoss()+searchnetWins.getPlayoffWin()-searchnetWins.getPlayoffLoss());
						if(NetWin>=lowest){

							//bestCoach.setnetWins(NetWin);
							this.mathlist.clear();//clear list in case I find a better coach
							this.mathlist.add(new CoachSeason(searchnetWins.getCoachID(), searchnetWins.getYear(), searchnetWins.getFirstName(), searchnetWins.getLastName(), searchnetWins.getSeasonWin(), searchnetWins.getSeasonLoss(), searchnetWins.getPlayoffWin(), searchnetWins.getPlayoffLoss(), searchnetWins.getTeam(), NetWin));
							lowest=NetWin;//assign ments for next iteration comaprison
						}
						
						//bestCoach.setnetWins(netwins)=bestCoach.getnetWins(NetWin);

						
						//double Max4Wins.NetWin = .max(mathlist, null);
						//this.bestcoaches.add(new CoachSeason(coachID, year, /*yearOrder,*/ firstName, lastName, seasonWin, seasonLoss, playOffWin, playOffLoss, team));
						
						//System.out.println(coachsearchN.getCoachID()+" "+ coachsearchN.getYear()+ " "+ coachsearchN.getFirstName()+" "+ coachsearchN.getLastName()+" "+ coachsearchN.getSeasonWin()+
						//" "+ coachsearchN.getSeasonLoss()+" "+ coachsearchN.getPlayoffWin()+" "+ coachsearchN.getPlayoffLoss()+" "+ coachsearchN.getTeam());
				}
				System.out.println(mathlist);//Print My best coach
			} else if (cmd.getCommand().equals("search_coaches")) {
			//	final CoachSeason findCoach = new CoachSeason(null, " ", null, null, "", "", "", "", null);
			
				//n is a input from the user to stop this loop to run
				//int n=0;
				//System.out.println("Enter 0 when you are finished entering the field names and values for your search for coach");
				System.out.println("FYI: For each field, Type coach_fieldyouwant: John");
				
				//Creating a while loop to keep taking input criteria from user:condition to stop user enters n
				//I am going to split the input from , for if the user want to enter multipl things
				
			    final String someString = input.next();
			    final String str2[] = someString.split("=");
				//final String str2[]=str.split(" = ");
				final CoachSeason findC = new CoachSeason(null, " ", null, null, "", "", "", "", null);
				//final String str2[]=str.split("=");
			    for(int i=0; i<str2.length; i++){
					if(str2[i]=="id"){
						final String findid=str2[i+1];
						findC.setCoachID(findid);
						
					}
					if(str2[i]=="year"){
						final String findyear=str2[i+1];
						final int findyearInt = Integer.parseInt(findyear);	
						findC.setYear(findyearInt);
					}
					if(str2[i]=="firstname"){
						final String findfirstname=str2[i+1];
						findC.setFirstName(findfirstname);
					}
					if(str2[i]=="lastname"){
						final String findlastname=str2[i+1];
						findC.setLastName(findlastname);
					}
					if(str2[i]=="seasonwin"){
						final String findseasonwin=str2[i+1];
						final int findseasonwinInt = Integer.parseInt(findseasonwin);	
						findC.setSeasonWin(findseasonwinInt);
					}
					if(str2[i]=="seasonloss"){
						final String findseasonloss=str2[i+1];
						final int findseasonlossInt = Integer.parseInt(findseasonloss);	
						findC.setSeasonLoss(findseasonlossInt);
					}
					if(str2[i]=="playoffwin"){
						final String playoffwin=str2[i+1];
						final int playoffwinInt = Integer.parseInt(playoffwin);	
						findC.setPlayoffWin(playoffwinInt);
					}
					if(str2[i]=="playoffloss"){
						final String playoffloss=str2[i+1];
						final int playofflossInt = Integer.parseInt(playoffloss);	
						findC.setPlayoffLoss(playofflossInt);
					}
					if(str2[i]=="team"){
						final String team=str2[i+1];
						findC.setTeam(team);
					}
					else{
						System.out.println("I need you to write the field in lower case");
					}
					//System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));
					System.out.println(findC.getCoachID()+" "+ findC.getYear()+ " "+ findC.getFirstName()+" "+ findC.getLastName()+" "+findC.getSeasonWin()+" "+findC.getSeasonLoss()+" "+findC.getPlayoffWin()+""+findC.getPlayoffLoss()+findC.getTeam());
			
				}

					/*for(final var search : coaches) {
						if(search.getCoachID().equals(findC.getCoachID())||search.getYear()==(findC.getYear())||search.getFirstName().equals(findC.getFirstName())||search.getLastName().equals(findC.getLastName())||search.getSeasonWin()==(findC.getSeasonWin())||search.getSeasonLoss()==(findC.getSeasonLoss())||search.getPlayoffWin()==(findC.getPlayoffWin())||search.getPlayoffLoss()==(findC.getPlayoffLoss())||search.getTeam().equals(findC.getTeam())
							|| search.getTeam().equals(findC.getTeam())) {
						//String lastnames=coachsearchN.getLastName();
						//System.out.println("Yes");
						//:wq
						//System.out.println("Coaches: " + this.coaches.toString().replaceAll("CoachSeason >>", "\nCoachSeason >>"));
							System.out.println(search.getCoachID()+" "+ search.getYear()+ " "+ search.getFirstName()+" "+ search.getLastName()+" "+search.getSeasonWin()+" "+search.getSeasonLoss()+" "+search.getPlayoffWin()+""+search.getPlayoffLoss()+search.getTeam());
					
						}
					}*/
					



				
				
				//I am going to split the input from , for if the user want to enter multipl things, 
				
				

				
				  

			} else if (cmd.getCommand().equals("exit")) {
				System.out.println("Leaving the database, goodbye!");
				break;
			} else if (cmd.getCommand().equals("")) {
			} else {
				System.out.println("Invalid Command, try again!");
			}

			if (result) {
				// ...
			}

			System.out.print("> ");
		}
	}

	private boolean doHelp() {
		System.out.println("add_coach ID SEASON FIRST_NAME LAST_NAME SEASON_WIN ");
		System.out.println("          EASON_LOSS PLAYOFF_WIN PLAYOFF_LOSS TEAM - add new coach data");
		System.out.println("add_team ID LOCATION NAME LEAGUE - add a new team");
		System.out.println("print_coaches - print a listing of all coaches");
		System.out.println("print_teams - print a listing of all teams");
		System.out.println("coaches_by_name NAME - list info of coaches with the specified name");
		System.out.println("teams_by_city CITY - list the teams in the specified city");
		System.out.println("load_coach FILENAME - bulk load of coach info from a file");
		System.out.println("load_team FILENAME - bulk load of team info from a file");
		System.out
				.println("best_coach SEASON - print the name of the coach with the most netwins in a specified season");
		System.out.println(
				"search_coaches field=VALUE - print the name of the coach satisfying the specified conditions");
		System.out.println("exit - quit the program");
		return true;
	}

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
	    //initialize Scanner
	    P1.input = new Scanner(System.in);
	    
		new P1().run();
		
		//close Scanner
		P1.input.close();
	}
}


