class CoachSeason {
    private String coachID;
    private int year;
    //private int yearOrder;
    private String firstName;
    private String lastName;
    private int seasonWin;
    private int seasonLoss;
    private int playoffWin;
    private int playoffLoss;
    private String team;
    private double netWins;

    public CoachSeason(final String coachID, final int year, /* int yearOrder, */ final String firstName,
            final String lastName, final int seasonWin, final int seasonLoss, final int playoffWin,
            final int playoffLoss, final String team) {
        this.coachID = coachID;
        this.year = year;
        /* this.yearOrder = yearOrder; */
        this.firstName = firstName;
        this.lastName = lastName;
        this.seasonWin = seasonWin;
        this.seasonLoss = seasonLoss;
        this.playoffWin = playoffWin;
        this.playoffLoss = playoffLoss;
        this.team = team;
    }

    public CoachSeason(final String coachID, final int year, /* int yearOrder, */ final String firstName,
            final String lastName, final int seasonWin, final int seasonLoss, final int playoffWin,
            final int playoffLoss, final String team, final double netWins) {
        this.coachID = coachID;
        this.year = year;
        /* this.yearOrder = yearOrder; */
        this.firstName = firstName;
        this.lastName = lastName;
        this.seasonWin = seasonWin;
        this.seasonLoss = seasonLoss;
        this.playoffWin = playoffWin;
        this.playoffLoss = playoffLoss;
        this.team = team;
        this.netWins = netWins;
    }

    public CoachSeason(Object coachID2, String string, Object firstName2, Object lastName2, String string2,
			String string3, String string4, String string5, Object team2) {
	}

	public static CoachSeason parseInput(final String rawInput) {
        final String[] inputParts = rawInput.split(",");
        return new CoachSeason(inputParts[0].trim(), Integer.parseInt(inputParts[1].trim()),
                /* Integer.parseInt(inputParts[2].trim()), */
                inputParts[2].trim(), inputParts[3].trim(), Integer.parseInt(inputParts[4].trim()),
                Integer.parseInt(inputParts[5].trim()), Integer.parseInt(inputParts[6].trim()),
                Integer.parseInt(inputParts[7].trim()), inputParts[8].trim());
    }

    /* public static CoachSeason parseInput2(final String rawInput) {
        final String[] inputParts = rawInput.split(",");
        return new CoachSeason(
            inputParts[0].trim(),
            Integer.parseInt(inputParts[1].trim()),
            inputParts[2].trim(),
            inputParts[3].trim(),
            Integer.parseInt(inputParts[4].trim()),
            Integer.parseInt(inputParts[5].trim()),
            Integer.parseInt(inputParts[6].trim()),
            Integer.parseInt(inputParts[7].trim()),
            inputParts[8].trim()),
            Integer.parseInt(inputParts[9].trim());
    }*/

    /**
     * @return the coachID
     */
    public String getCoachID() {
        return coachID;
    }

    /**
     * @param coachID the coachID to set
     */
    public void setCoachID(final String coachID) {
        this.coachID = coachID;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(final int year) {
        this.year = year;
    }
    /*
     * /**
     * 
     * @return the yearOrder
     */
    /*
     * public int getYearOrder() { return yearOrder; }
     */

    /*
     * /**
     * 
     * @param yearOrder the yearOrder to set
     */
    /*
     * public void setYearOrder(int yearOrder) { this.yearOrder = yearOrder; }
     */

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the seasonWin
     */
    public int getSeasonWin() {
        return seasonWin;
    }

    /**
     * @param seasonWin the seasonWin to set
     */
    public void setSeasonWin(final int seasonWin) {
        this.seasonWin = seasonWin;
    }

    /**
     * @return the seasonLoss
     */
    public int getSeasonLoss() {
        return seasonLoss;
    }

    /**
     * @param seasonLoss the seasonLoss to set
     */
    public void setSeasonLoss(final int seasonLoss) {
        this.seasonLoss = seasonLoss;
    }

    /**
     * @return the playoffWin
     */
    public int getPlayoffWin() {
        return playoffWin;
    }

    /**
     * @param playoffWin the playoffWin to set
     */
    public void setPlayoffWin(final int playoffWin) {
        this.playoffWin = playoffWin;
    }

    /**
     * @return the playoffLoss
     */
    public int getPlayoffLoss() {
        return playoffLoss;
    }

    /**
     * @param playoffLoss the playoffLoss to set
     */
    public void setPlayoffLoss(final int playoffLoss) {
        this.playoffLoss = playoffLoss;
    }

    /**
     * @return the team
     */
    public String getTeam() {
        return team;
    }
    /**
     * @param team the team to set
     */
    public void setTeam(final String team) {
        this.team = team;
    }

    /**
     * @param netWins the netWins to set
     */
    public void setnetWins(final double netwins) {
        this.netWins = netwins;
    }
    /**
     * @return the netWins
     */
    public double getnetWins() {
        return netWins;
    }

    @Override
    public String toString() {
        return String.format("CoachSeason >> Coach ID: %s, Year: %d, First Name: %s, Last Name: %s, Season Win: %d, Season Loss: %d, Playoff Win: %d, Playoff Loss: %d, Team: %s",
                this.coachID,
                this.year,
                /*this.yearOrder,*/
                this.firstName,
                this.lastName,
                this.seasonWin,
                this.seasonLoss,
                this.playoffWin,
                this.playoffLoss,
                this.team);
    }

    // public void load_coaches (){
    // FileInputStream instream = null;
    // FileOutputStream outstream = null;

    // try{
    // File infile =new File("coaches_season.txt");
    // File outfile =new File("writeC.txt");

    // instream = new FileInputStream(infile);
    // outstream = new FileOutputStream(outfile);

    // byte[] buffer = new byte[1024];

    // int length;
    // /*copying the contents from input stream to
    // * output stream using read and write methods
    // */
    // while ((length = instream.read(buffer)) > 0){
    // outstream.write(buffer, 0, length);
    // }

    // //Closing the input/output file streams
    // instream.close();
    // outstream.close();

    // System.out.println("File copied successfully!!");

    // }catch(IOException ioe){
    // ioe.printStackTrace();
    // }

    // // reading text file into ArrayList in Java 6
    // BufferedReader bufReader = new BufferedReader(new FileReader("writeC.txt"));
    // ArrayList<CoachSeason>ClistOfLines = new ArrayList<>();

    // String line = bufReader.readLine();
    // while (line != null) {
    // ClistOfLines.add(line);
    // line = bufReader.readLine();
    // }

    // bufReader.close();
    // System.out.println("Content of ArrayLiList:");
    // System.out.println(ClistOfLines);

    // }
    /*
     * public static void main(String[] args) { try { File myObj = new
     * File("teams.txt"); Scanner myReader = new Scanner(myObj); while
     * (myReader.hasNextLine()) { String data = myReader.nextLine();
     * System.out.println(data); } myReader.close(); } catch (FileNotFoundException
     * e) { System.out.println("An error occurred."); e.printStackTrace(); } }
     * 
     */

}