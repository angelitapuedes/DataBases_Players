class Team {
    private String team;
    private String location;
    private String name;
    private String league;

    public Team(final String team, final String location, final String name, final String league) {
        this.team = team;
        this.location = location;
        this.name = name;
        this.league = league;
    }

    public static Team parseInput(final String rawInput) {
        final String[] inputParts = rawInput.split(",");
        return new Team(inputParts[0], inputParts[1], inputParts[2], inputParts[3]);
    }

    /**
     * @return the team
     */
    public String getTeam() {
        return team;
    }

    /**
     * @param team the team to set
     */
    public void setTeam(final String team) {
        this.team = team;
    }

    /**
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(final String location) {
        this.location = location;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the league
     */
    public String getLeague() {
        return league;
    }

    /**
     * @param league the league to set
     */
    public void setLeague(final String league) {
        this.league = league;
    }

    @Override
    public String toString() {
        return String.format("Team >> Team: %s, Location: %s, Name: %s, League: %s",
                this.team,
                this.location,
                this.name,
                this.league);
    }
}

    