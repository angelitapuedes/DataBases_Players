Title Coaches and Seasons Database

This project was based on creating a database to take in coaches data and team data and search for specified inforamtion on the data

This program uses object oriented concepts with a coach class and a team class that accesses data and transfers data from a file to a list data structure

Tests

to run the program you can test each function based on the following:

1. Add_coach, This function you can receive prompts to enter speicifc information to create a coach profile, this coach would be added to the database
2. Add_team Follows the same process as add_coach but with team required values
3. Print Coaches prints the coaches that are in the data base, you can just enter print_coaches and the cocahes will print_coaches
4. Print Teams follows the same process as for coaches
5. Coaches_by name, there will be a prompt to enter the coaches last name